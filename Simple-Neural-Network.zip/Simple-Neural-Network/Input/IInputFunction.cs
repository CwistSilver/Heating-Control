﻿namespace Simple_Neural_Network.Input;
public interface IInputFunction
{
    double CalculateInput(List<ISynapse> inputs);
}
