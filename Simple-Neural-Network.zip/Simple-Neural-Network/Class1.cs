﻿namespace Simple_Neural_Network;

public class Class1
{

}
