﻿namespace Simple_Neural_Network.Activation;
public interface IActivationFunction
{
    double CalculateOutput(double input);
}
